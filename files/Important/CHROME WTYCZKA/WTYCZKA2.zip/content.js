console.log("Wtyczka działa!");

function simulateClick(element) {
    if (element) {
        var event = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true
        });
        element.dispatchEvent(event);
    }
}

function setVolumeToMax() {
    var videoElement = document.querySelector('video');
    if (videoElement) {
        videoElement.volume = 1.0;
        console.log('Głośność ustawiona na 100%');
    } else {
        console.log('Nie znaleziono elementu wideo');
    }
}

function selectQuality() {
    var settingsButton = document.querySelector('.pb-settings-click');
    if (settingsButton) {
        simulateClick(settingsButton);
        setTimeout(() => {
            var qualityItem = document.querySelector('li[data-value="hd"] a');
            if (qualityItem) {
                simulateClick(qualityItem);
            } else {
                var qualityItemSD = document.querySelector('li[data-value="sd"] a');
                if (qualityItemSD) {
                    simulateClick(qualityItemSD);
                } else {
                    console.log('Nie znaleziono opcji jakości HD ani SD');
                }
            }
        }, 100);
        setVolumeToMax();
    } else {
        console.log('Nie znaleziono przycisku ustawień');
    }
}

function setupVideoListener() {
    var videoElement = document.querySelector('video');
    if (videoElement) {
        console.log('Dodano nasłuchiwanie na załadowanie filmu');
        videoElement.addEventListener('loadeddata', function handler() {
            selectQuality();
            videoElement.removeEventListener('loadeddata', handler); // Usuwamy po pierwszym uruchomieniu
        });

        // Nasłuchuj klawiszy do przewijania filmu
        document.addEventListener('keydown', function(event) {
            if (videoElement) {
                switch (event.key) {
                    case 'x': // Przewijanie o 10s do przodu
                        videoElement.currentTime += 10;
                        console.log('Przewinięto o 10 sekund do przodu');
                        break;
                    case 'z': // Przewijanie o 10s do tyłu
                        videoElement.currentTime -= 10;
                        console.log('Przewinięto o 10 sekund do tyłu');
                        break;
                    case 'e': // Przewijanie o 5s do przodu
                        videoElement.currentTime += 5;
                        console.log('Przewinięto o 5 sekund do przodu');
                        break;
                }
            }
        });
    } else {
        console.log('Brak elementu wideo, ponawianie sprawdzania...');
        setTimeout(setupVideoListener, 500);
    }
}

setupVideoListener();
